package com.AdvanceTraining1_1;

import java.util.Scanner;

//Write a program to list all, even numbers less than or equal to the number n. Take the value of n as input from the user.


public class ListAllEvenNumbersLessOrEqualToN {

	public static void main(String []args)
    {
		int n;
		
		System.out.println("Enter a number: ");
		
        Scanner scan = new Scanner(System.in);
        
        n=scan.nextInt();
        
        System.out.println("Even Numbers from 1 to "+n+" are: ");

		for (int i = 1; i <= n; i++) {
			   if (i % 2 == 0)   // So if %2 is a even number 
			   {

					 System.out.println(i + " ");
		
    }
}
    }
}

