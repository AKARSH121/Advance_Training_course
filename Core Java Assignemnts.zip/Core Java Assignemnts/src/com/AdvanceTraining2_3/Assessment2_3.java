package com.AdvanceTraining2_3;

public class Assessment2_3 {

	static int A[] =  {3, 2, 4, 5, 6, 4, 5, 7, 3, 2, 3, 4, 7, 1, 2, 0, 0, 0};
	 static int length = A.length;
public static void main(String[] args) {
	
	System.out.println("Sum of given array is  :" + sum());  //sum
	
	average();// average
	 
	int n= A.length;
	System.out.println( "smallest element of array is : " + getSmallestValue(A, n));// smallest value
	System.out.println( "element at 17 index is : "+A[17]);
	}
public static  int sum() {
int sum=0;
for (int i = 0; i < A.length-4; i++) {
	sum += A[i];
	
}
A[15]=sum;
System.out.println( "element at 15 index is : "+A[15]);
return sum;

}

public static double average() {
	
	int sum = 0;
	for (int i = 0; i < A.length; i++) {
       sum += A[i];
   }

   double average = sum / length;
    A[16]=(int) average;
    System.out.println( "element at 16 index is : "+A[16]);
   System.out.println("Average of array : "+average);
	return average;
}

public static int getSmallestValue(int A[],int n) {
int res = A[0];
for (int i = 1; i < n; i++) 
	 res = Math.min(res, A[i]);
res=A[17];
return res;
	

	
}

}

	
	
	
	
	
