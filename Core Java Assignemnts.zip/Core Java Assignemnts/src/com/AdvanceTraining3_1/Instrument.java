package com.AdvanceTraining3_1;

public abstract class Instrument
{
public abstract void Play();
}